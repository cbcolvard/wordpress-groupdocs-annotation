edButtons[edButtons.length] =
new edButton('gd_annotation'
	,'gd_annotation'
	,'[grpdocsannotation file="'
	,'" width="500" height="600" protocol="http"]'
	,'1'
);